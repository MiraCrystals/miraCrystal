import React from 'react';
import { motion } from 'framer-motion';
import { ShoppingCart, Star, Sparkles } from 'lucide-react';

const products = [
  {
    name: "Amethyst Cluster",
    price: "$45",
    image: "https://cdn.omegahub.co.uk/media/2020/01/26102207/Crystal-Reiki-Grid.jpg",
    description: "Promotes tranquility and spiritual growth",
    rating: 5,
    energy: "Calming",
    chakra: "Crown"
  },
  {
    name: "Rose Quartz Heart",
    price: "$32",
    image: "https://cdn.omegahub.co.uk/media/2020/01/26102207/Crystal-Reiki-Grid.jpg",
    description: "Opens the heart chakra to unconditional love",
    rating: 5,
    energy: "Love",
    chakra: "Heart"
  },
  {
    name: "Clear Quartz Point",
    price: "$28",
    image: "https://cdn.omegahub.co.uk/media/2020/01/26102207/Crystal-Reiki-Grid.jpg",
    description: "Amplifies energy and brings mental clarity",
    rating: 5,
    energy: "Clarity",
    chakra: "Crown"
  },
  {
    name: "Citrine Tumbled Stone",
    price: "$22",
    image: "https://cdn.omegahub.co.uk/media/2020/01/26102207/Crystal-Reiki-Grid.jpg",
    description: "Attracts abundance and positive energy",
    rating: 5,
    energy: "Abundance",
    chakra: "Solar Plexus"
  },
  {
    name: "Green Aventurine Palm Stone",
    price: "$35",
    image: "https://cdn.omegahub.co.uk/media/2020/01/26102207/Crystal-Reiki-Grid.jpg",
    description: "Brings luck and emotional healing",
    rating: 5,
    energy: "Healing",
    chakra: "Heart"
  },
  {
    name: "Black Tourmaline Raw",
    price: "$38",
    image: "https://cdn.omegahub.co.uk/media/2020/01/26102207/Crystal-Reiki-Grid.jpg",
    description: "Powerful protection against negative energy",
    rating: 5,
    energy: "Protection",
    chakra: "Root"
  }
];

const FeaturedProducts = () => {
  return (
    <section id="products" className="py-24 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Floating Background Elements */}
      <div className="absolute inset-0">
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-gold-400/30 rounded-full"
            animate={{
              y: [0, -100, 0],
              x: [0, Math.random() * 50 - 25, 0],
              opacity: [0.3, 0.8, 0.3],
            }}
            transition={{
              duration: 8 + Math.random() * 4,
              repeat: Infinity,
              ease: "easeInOut",
              delay: Math.random() * 5,
            }}
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
          />
        ))}
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <motion.h2
            className="text-5xl md:text-6xl font-serif font-bold text-sage-800 mb-8"
            animate={{ 
              textShadow: [
                '0 0 0px rgba(90, 122, 90, 0)',
                '0 0 20px rgba(90, 122, 90, 0.3)',
                '0 0 0px rgba(90, 122, 90, 0)'
              ]
            }}
            transition={{ duration: 4, repeat: Infinity }}
          >
            Sacred Crystal Collection
          </motion.h2>
          <p className="text-xl text-sage-600 max-w-3xl mx-auto font-handwritten">
            Handpicked crystals to support your healing journey and spiritual awakening
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50, scale: 0.9 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ 
                y: -15,
                rotateY: 5,
                rotateX: 5,
              }}
              className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl overflow-hidden group relative"
            >
              {/* Aura Effect */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-br from-sage-200/20 via-transparent to-gold-200/20 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                animate={{
                  scale: [1, 1.05, 1],
                  opacity: [0, 0.3, 0],
                }}
                transition={{ duration: 3, repeat: Infinity }}
              />

              <div className="relative overflow-hidden">
                <motion.img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-64 object-cover"
                  whileHover={{ scale: 1.1 }}
                  transition={{ duration: 0.5 }}
                />
                
                {/* Shimmer Overlay */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"
                />
                
                {/* Floating Sparkles */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                  {[...Array(5)].map((_, i) => (
                    <motion.div
                      key={i}
                      className="absolute w-1 h-1 bg-gold-400 rounded-full"
                      animate={{
                        y: [0, -30, 0],
                        opacity: [0, 1, 0],
                        scale: [0, 1, 0],
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        delay: i * 0.3,
                      }}
                      style={{
                        left: `${20 + i * 15}%`,
                        top: '70%',
                      }}
                    />
                  ))}
                </div>
              </div>

              <div className="p-6 relative">
                {/* Energy Indicators */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-1">
                    {[...Array(product.rating)].map((_, i) => (
                      <motion.div
                        key={i}
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ delay: i * 0.1 }}
                      >
                        <Star className="h-4 w-4 text-gold-400 fill-current" />
                      </motion.div>
                    ))}
                  </div>
                  <div className="flex items-center space-x-2 text-xs text-sage-600">
                    <span className="bg-sage-100 px-2 py-1 rounded-full">{product.energy}</span>
                    <span className="bg-gold-100 px-2 py-1 rounded-full">{product.chakra}</span>
                  </div>
                </div>

                <h3 className="text-xl font-serif font-bold text-sage-800 mb-2">
                  {product.name}
                </h3>
                
                <p className="text-sage-600 text-sm mb-4 leading-relaxed font-handwritten">
                  {product.description}
                </p>

                <div className="flex items-center justify-between">
                  <motion.span
                    className="text-2xl font-bold text-sage-800"
                    animate={{ scale: [1, 1.05, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    {product.price}
                  </motion.span>
                  
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="bg-gradient-to-r from-sage-600 to-sage-700 text-white px-6 py-2 rounded-full flex items-center space-x-2 hover:from-sage-700 hover:to-sage-800 transition-all duration-300 shadow-lg hover:shadow-xl relative overflow-hidden group"
                  >
                    <ShoppingCart className="h-4 w-4" />
                    <span>Add to Cart</span>
                    
                    {/* Button Glow Effect */}
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-gold-400/30 to-sage-400/30 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      animate={{
                        scale: [1, 1.1, 1],
                      }}
                      transition={{ duration: 2, repeat: Infinity }}
                    />
                  </motion.button>
                </div>
              </div>

              {/* Crystal Aura Ring */}
              <motion.div
                className="absolute inset-0 border-2 border-gold-400/50 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                animate={{
                  scale: [1, 1.02, 1],
                  opacity: [0, 0.5, 0],
                }}
                transition={{ duration: 3, repeat: Infinity }}
              />
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="text-center mt-16"
        >
          <motion.button
            whileHover={{ 
              scale: 1.05,
              boxShadow: "0 20px 40px rgba(90, 122, 90, 0.3)",
            }}
            whileTap={{ scale: 0.95 }}
            className="bg-transparent border-2 border-sage-600 text-sage-600 px-10 py-4 rounded-full font-medium text-lg hover:bg-sage-600 hover:text-white transition-all duration-300 relative overflow-hidden group"
          >
            <span className="relative z-10 flex items-center space-x-2">
              <Sparkles className="h-5 w-5" />
              <span>Explore Full Collection</span>
            </span>
            
            {/* Ripple Effect */}
            <motion.div
              className="absolute inset-0 bg-sage-600/20 rounded-full scale-0 group-hover:scale-100 transition-transform duration-500"
            />
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

export default FeaturedProducts;