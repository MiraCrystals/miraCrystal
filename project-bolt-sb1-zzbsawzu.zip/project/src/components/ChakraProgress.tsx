import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const chakras = [
  { name: 'Root', color: '#DC2626', symbol: '🔴' },
  { name: 'Sacral', color: '#EA580C', symbol: '🟠' },
  { name: 'Solar', color: '#EAB308', symbol: '🟡' },
  { name: 'Heart', color: '#16A34A', symbol: '💚' },
  { name: 'Throat', color: '#2563EB', symbol: '🔵' },
  { name: 'Third Eye', color: '#7C3AED', symbol: '🟣' },
  { name: 'Crown', color: '#A855F7', symbol: '🟢' },
];

const ChakraProgress = () => {
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = (window.scrollY / totalHeight) * 100;
      setScrollProgress(progress);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const activeChakra = Math.floor((scrollProgress / 100) * chakras.length);

  return (
    <div className="fixed right-6 top-1/2 transform -translate-y-1/2 z-50 space-y-4">
      {chakras.map((chakra, index) => (
        <motion.div
          key={index}
          className={`w-8 h-8 rounded-full border-2 flex items-center justify-center cursor-pointer transition-all duration-300 ${
            index <= activeChakra
              ? 'border-white shadow-lg scale-110'
              : 'border-white/50 scale-90'
          }`}
          style={{
            backgroundColor: index <= activeChakra ? chakra.color : 'transparent',
          }}
          whileHover={{ scale: 1.2 }}
          animate={{
            boxShadow: index === activeChakra 
              ? `0 0 20px ${chakra.color}50` 
              : '0 0 0px transparent',
          }}
          title={chakra.name}
        >
          <motion.div
            animate={{
              rotate: index === activeChakra ? 360 : 0,
            }}
            transition={{
              duration: 2,
              repeat: index === activeChakra ? Infinity : 0,
              ease: "linear",
            }}
            className="text-xs"
          >
            {chakra.symbol}
          </motion.div>
        </motion.div>
      ))}
    </div>
  );
};

export default ChakraProgress;