import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import QuoteShowcase from './components/QuoteShowcase';
import FeaturedProducts from './components/FeaturedProducts';
import FounderSection from './components/FounderSection';
import Contact from './components/Contact';
import Footer from './components/Footer';
import WaveSection from './components/WaveSection';
import SpiritualBackground from './components/SpiritualBackground';
import ChakraProgress from './components/ChakraProgress';
import SoundToggle from './components/SoundToggle';

function App() {
  return (
    <div className="min-h-screen relative">
      <SpiritualBackground />
      <ChakraProgress />
      <SoundToggle />
      
      <div className="relative z-10">
        <Navbar />
        <Hero />
        <WaveSection />
        <QuoteShowcase />
        <WaveSection reverse />
        <FeaturedProducts />
        <WaveSection />
        <FounderSection />
        <WaveSection reverse />
        <Contact />
        <Footer />
      </div>
    </div>
  );
}

export default App;